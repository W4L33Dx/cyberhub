from random import randint
from Crypto.Util.number import long_to_bytes ,getPrime , bytes_to_long
from gmpy2 import gcd
from flag import FLAG,p,q


a = 117245475703816923815954637545330403936684231812585931512816300583010693822124660722224072064139026100075135636111040688459248563114027921262512742947228062862778640389139447789215166486769942849894119051868324504460416505290451017036626747537549341382015820139386971905248519385631638971800528966684635030733
n = p*q
e1 = 12886657667389660800780796462970504910193928992888518978200029826975978624718627799215564700096007849924866627154987365059524315097631111242449314835868137
e2 = 12110586673991788415780355139635579057920926864887110308343229256046868242179445444897790171351302575188607117081580121488253540215781625598048021161675697
c1 = pow((2*p + 3*q),e1,n)
c2 = pow((5*p + 7*q),e2,n)


def encrypt_flag(flag,p):
    ciphertext = []
    plaintext = ''.join([bin(i)[2:].zfill(8) for i in flag])
    for b in plaintext:
        e = randint(1, p)
        n = pow(a, e, p)
        if b == '1':
            ciphertext.append(n)
        else:
            n = -n % p
            ciphertext.append(n)
    return ciphertext


ciphers = encrypt_flag(FLAG,p) 

output = open("output.py","w")
output.write("n = "+str(n))
output.write("\ne1 = "+str(e1))
output.write("\ne2 = "+str(e2))
output.write("\nc1 = "+str(c1))
output.write("\nc2 = "+str(c2))
output.write("\nciphers = "+str(ciphers))
output.close()
