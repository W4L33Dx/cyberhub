from Crypto.Cipher import DES
import binascii

flag=[Removed]
key = binascii.unhexlify([Removed])
cipher = DES.new(key, DES.MODE_ECB)
print(binascii.hexlify(cipher.encrypt(flag.encode())))
